$('.sidebar-offcanvas').affix({
      offset: {
        top: 245
      }
});

var $body   = $(document.body);
var navHeight = $('.navbar').outerHeight(true) + 10;

$body.scrollspy({
	target: '.sidebar-offcanvas',
	offset: navHeight
});
