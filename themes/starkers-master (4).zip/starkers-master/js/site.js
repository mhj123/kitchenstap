
	jQuery(document).ready(function($) {

		$('[data-toggle="popover"]').popover({trigger: 'click','placement': 'right'});


	});

