

	STARKERS

	Created by Viewport Industries, Ltd.

	- - - - - - - - - - - - - - - - - - - - - - -

	Starkers is a bare-bones WordPress theme 
	created to act as a starting point for the 
	theme designer. Free of all style, 
	presentational elements, and non-semantic 
	markup, Starkers is the perfect ‘blank slate’ 
	for all your WordPress projects.

	Best of all: it’s free and fully GPL-licensed, 
	so you can use it for whatever you like — even 
	commercial work.

	Up until now, Starkers has merely been a 
	stripped-back version of the default theme 
	that ships with WordPress, and as a result has 
	never been quite as ‘naked’ as it could be. 
	Now we’ve brought it under the Viewport 
	Industries banner and have rebuilt it from the 
	ground up. Literally. Not one line of code is 
	the same.

	For more details, please visit:
	http://viewportindustries.com/products/starkers/

	- - - - - - - - - - - - - - - - - - - - - - -

	Version 4.0, updated 20.08.2012

	Normalising file comments and removal of template name

	Version 4.0, updated 02.08.2012

	Completely re-written from the ground up, 
	using our own code. This version shares no
	common ground whatsoever with the previous 
	builds listed below.

	- - - - - - - - - - - - - - - - - - - - - - -
	- - - - - - - - - - - - - - - - - - - - - - -
	- - - - - - - - - - - - - - - - - - - - - - -
	- - - - - - - - - - - - - - - - - - - - - - -


	Version 3.0, updated 21.06.2010

	NB: This is now available on the 3.0 branch

	Re-built using 'Twenty Ten' theme as its base

	- - - - - - - - - - - - - - - - - - - - - - -

	Version 2.8.5, updated 11.11.2009

	Changed brand-wide typeface to FS Clerkenwell

	- - - - - - - - - - - - - - - - - - - - - - -

	Version 2.8.2, revision 1, updated 23.07.2009

	Corrected: closing </div> tag in comments.php on line 87

	- - - - - - - - - - - - - - - - - - - - - - -

	Version 2.8.2 for WP2.8.2, updated 21.07.2009

	Removed: Extra '>' in comments.php on line 50
	Changed: Commented out 'div, ul, li { position:relative }' in layout.css
	Added: GPL License included as '_LICENSE.txt'
	Renamed: 'READ_ME.txt' becomes '_READ_ME.txt'

	- - - - - - - - - - - - - - - - - - - - - - -

	Version 2.8.1 for WP2.8.1, updated 12.07.2009

	Re-written from scratch, using the 'Default'
	theme included with WordPress 2.8 as a basis.

	- - - - - - - - - - - - - - - - - - - - - - -
	
	Versions 2.3 - 2.7

	Non-existent. Starkers is now named according to 
	the version of WordPress with which it is compatible.

	- - - - - - - - - - - - - - - - - - - - - - -

	Version 2.2 for WP2.6.2, updated 02.11.2008

	Fixed: prev / next links typo in archive.php & index.php
	Fixed: closing </p> tag in comments.php

	- - - - - - - - - - - - - - - - - - - - - - -

	Version 2.1 for WP2.6.2, updated 29.09.2008

	Added: WP image-alignment and caption CSS
	Added: Page listing
	Removed: _comments-popup.php
	Fixed: prev / next links typo
	Fixed: duplicate 'h5' typo in reset.css

	- - - - - - - - - - - - - - - - - - - - - - -

	Enjoy!

	~ Elliot Jay Stocks & Keir Whitaker

