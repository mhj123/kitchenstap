<?php
require_once 'class.file.php';

/**
 * Description of class
 *
 * @author Srdjan
 */
class WPToolset_Field_Video extends WPToolset_Field_File
{

    protected $_settings = array('min_wp_version' => '3.6');

}