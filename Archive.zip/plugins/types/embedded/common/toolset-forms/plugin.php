<?php
/**
 * @package Toolset
 * @version 0.1
 */
/*
Plugin Name: Toolset forms
Plugin URI: http://wp-types.com/toolset-forms/
Description: Form factory
Author: OTS Toolset team
Version: 0.1
Author URI: http://wp-types.com/
*/
require_once 'bootstrap.php';
//include 'test.php';