<?php
/*
 * Messages.
 */

$messages = array(
    'warning_singular_plural_match' => __( "It is not recommended to have same plural and singular name for a post type. Please use a different name for the singular and plural names.",
            'wpcf' ),
);
