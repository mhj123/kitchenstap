<?php
// Added check because of activation hook and theme embedded code
if (!defined('WPCF_META_PREFIX')) {
    define('WPCF_META_PREFIX', 'wpcf-');
}